# -*- coding: utf-8 -*-
"""Dextop WhatsApp Voice Dual - módulo Beta.

Gestiona WhatsApp Beta en el puerto 59223. El modo dual se inicia desde
el módulo Desktop con NVDA+Control+Shift+W dos veces.
"""

import base64
import ctypes
import globalPluginHandler
import globalVars
import json
import logging
import os
import random
import socket
import struct
import subprocess
import threading
import time
import urllib.parse
import urllib.request
import winreg

import addonHandler

try:
    import ui
except Exception:
    ui = None
try:
    from scriptHandler import script
except Exception:
    script = None

addonHandler.initTranslation()

log = logging.getLogger("nvda.dextop_whatsapp_voice_beta")

DEBUG_PORT = 59223
DEBUG_ARG = "--remote-debugging-port=%d --remote-allow-origins=http://127.0.0.1" % DEBUG_PORT
ENV_NAME = "WEBVIEW2_ADDITIONAL_BROWSER_ARGUMENTS"
REG_PATHS = [
    r"Software\Policies\Microsoft\Edge\WebView2\AdditionalBrowserArguments",
    r"Software\Microsoft\Edge\WebView2\AdditionalBrowserArguments",
]
ENV_REG_PATH = r"Environment"
TARGET_NAME = "WhatsApp Beta"
DISPLAY_NAME = "Dextop WhatsApp Voice Beta"

# Claves conocidas de esta variante.
BASE_APP_KEYS = ['5319275A.51895FA4EA97F_cv1g1gvanyjgm!App', '5319275A.51895FA4EA97F_cv1g1gvanyjgm', '5319275A.51895FA4EA97F']
LEGACY_GENERIC_KEYS = ['WhatsApp.Root.exe', 'WhatsApp.exe', 'WhatsAppDesktop.exe', 'WhatsAppBeta.exe', 'WhatsApp.Beta.exe', 'WhatsAppDesktopBeta.exe', 'WhatsAppBeta', 'WhatsApp.WhatsAppBeta', '5319275A.WhatsAppBeta', '5319275A.WhatsAppBeta_cv1g1gvanyjgm', '5319275A.WhatsAppBeta_cv1g1gvanyjgm!App', '5319275A.WhatsAppBeta_cv1g1gvanyjgm!WhatsApp', '5319275A.WhatsAppBeta_cv1g1gvanyjgm!WhatsAppBeta', '5319275A.WhatsAppDesktop_cv1g1gvanyjgm!WhatsApp', 'Chrome._crx_hnpfjngllnfapefoaidbinmjnm', '*']

# Versión de convivencia: NO usa comodín ni variable global, porque eso haría
# que Desktop y Beta se pisen. Solo escribe claves específicas para Beta.
USE_WILDCARD_AND_USER_ENVIRONMENT = False
KNOWN_OUR_PORTS = (59222, 59223)


class MinWSClient:
    """Cliente WebSocket mínimo para comunicarse con Chrome DevTools Protocol."""

    def __init__(self, ws_url):
        self.ws_url = ws_url
        self.sock = None

    def connect(self):
        parsed = urllib.parse.urlparse(self.ws_url)
        host = parsed.hostname or "127.0.0.1"
        port = parsed.port or DEBUG_PORT
        path = parsed.path or "/"
        if parsed.query:
            path += "?" + parsed.query

        self.sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.sock.settimeout(4.0)
        self.sock.connect((host, port))

        sec_key = base64.b64encode(bytes(random.randint(0, 255) for _ in range(16))).decode("utf-8")
        handshake = (
            "GET %s HTTP/1.1\r\n"
            "Host: %s:%d\r\n"
            "Upgrade: websocket\r\n"
            "Connection: Upgrade\r\n"
            "Sec-WebSocket-Key: %s\r\n"
            "Sec-WebSocket-Version: 13\r\n"
            "Origin: http://127.0.0.1\r\n\r\n"
        ) % (path, host, port, sec_key)
        self.sock.sendall(handshake.encode("utf-8"))

        response = b""
        while b"\r\n\r\n" not in response:
            chunk = self.sock.recv(1024)
            if not chunk:
                break
            response += chunk
            if len(response) > 8192:
                raise Exception("Handshake de WebSocket demasiado largo")
        if b" 101 " not in response:
            raise Exception("Fallo en el handshake de WebSocket: " + response[:300].decode("utf-8", "ignore"))

    def send_text(self, text):
        data = text.encode("utf-8")
        length = len(data)
        frame = bytearray([0x81])
        if length < 126:
            frame.append(0x80 | length)
        elif length <= 0xFFFF:
            frame.append(0x80 | 126)
            frame.extend(struct.pack("!H", length))
        else:
            frame.append(0x80 | 127)
            frame.extend(struct.pack("!Q", length))
        mask = [random.randint(0, 255) for _ in range(4)]
        frame.extend(mask)
        frame.extend(bytearray(b ^ mask[i % 4] for i, b in enumerate(data)))
        self.sock.sendall(frame)

    def close(self):
        if self.sock:
            try:
                self.sock.close()
            except Exception:
                pass
            self.sock = None


def discover_target_app_ids():
    """Intenta descubrir AppUserModelIDs de la variante publicada en el menú inicio."""
    ids = []
    try:
        cmd = [
            "powershell.exe", "-NoProfile", "-ExecutionPolicy", "Bypass", "-Command",
            "Get-StartApps | Where-Object { $_.Name -eq 'WhatsApp Beta' -or $_.AppID -like '5319275A.51895FA4EA97F*' } | Select-Object -ExpandProperty AppID"
        ]
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=6, creationflags=0x08000000)
        for line in (result.stdout or "").splitlines():
            line = line.strip()
            if line and line not in ids:
                ids.append(line)
    except Exception as e:
        log.debug("%s: No se pudo descubrir AppID por PowerShell: %s", DISPLAY_NAME, e)
    return ids


def registry_value_names():
    names = list(dict.fromkeys(BASE_APP_KEYS + discover_target_app_ids()))
    if USE_WILDCARD_AND_USER_ENVIRONMENT:
        names.append("*")
    return names


def _broadcast_environment_change():
    """Notifica a Explorer que cambió el entorno de usuario."""
    try:
        HWND_BROADCAST = 0xFFFF
        WM_SETTINGCHANGE = 0x001A
        SMTO_ABORTIFHUNG = 0x0002
        ctypes.windll.user32.SendMessageTimeoutW(
            HWND_BROADCAST,
            WM_SETTINGCHANGE,
            0,
            "Environment",
            SMTO_ABORTIFHUNG,
            3000,
            None,
        )
    except Exception as e:
        log.debug("%s: No se pudo enviar WM_SETTINGCHANGE: %s", DISPLAY_NAME, e)


def _has_our_debug_arg(value):
    text = str(value or "")
    return any("remote-debugging-port=%d" % port in text for port in KNOWN_OUR_PORTS)


def cleanup_old_configuration():
    """Limpia restos propios y restos globales antiguos sin tocar la variante Desktop."""
    names = list(dict.fromkeys(BASE_APP_KEYS + discover_target_app_ids() + LEGACY_GENERIC_KEYS))
    for key_path in REG_PATHS:
        try:
            key = winreg.OpenKey(winreg.HKEY_CURRENT_USER, key_path, 0, winreg.KEY_SET_VALUE | winreg.KEY_QUERY_VALUE)
            for name in names:
                try:
                    current, _ = winreg.QueryValueEx(key, name)
                    if name in LEGACY_GENERIC_KEYS:
                        # Las claves genéricas fueron usadas por versiones anteriores y pisan Desktop/Beta.
                        # Se eliminan aunque tengan el mismo puerto de esta variante.
                        if _has_our_debug_arg(current):
                            winreg.DeleteValue(key, name)
                            log.info("%s: clave genérica antigua eliminada en %s para %s", DISPLAY_NAME, key_path, name)
                    elif _has_our_debug_arg(current) and current != DEBUG_ARG:
                        winreg.DeleteValue(key, name)
                        log.info("%s: configuración anterior eliminada en %s para %s", DISPLAY_NAME, key_path, name)
                except FileNotFoundError:
                    pass
            winreg.CloseKey(key)
        except FileNotFoundError:
            pass
        except Exception as e:
            log.error("%s: Error limpiando configuración anterior: %s", DISPLAY_NAME, e)

    cleanup_global_legacy_configuration()



def cleanup_global_legacy_configuration():
    """Quita configuraciones globales de versiones anteriores: comodín * y variable de entorno.

    Estas configuraciones no pueden convivir con puertos separados, porque afectan a
    todas las apps WebView2. No borra las claves específicas de WhatsApp Desktop.
    """
    for key_path in REG_PATHS:
        try:
            key = winreg.OpenKey(winreg.HKEY_CURRENT_USER, key_path, 0, winreg.KEY_SET_VALUE | winreg.KEY_QUERY_VALUE)
            try:
                current, _ = winreg.QueryValueEx(key, "*")
                if _has_our_debug_arg(current):
                    winreg.DeleteValue(key, "*")
                    log.info("%s: comodín global antiguo eliminado en %s", DISPLAY_NAME, key_path)
            except FileNotFoundError:
                pass
            winreg.CloseKey(key)
        except FileNotFoundError:
            pass
        except Exception as e:
            log.error("%s: Error limpiando comodín global antiguo: %s", DISPLAY_NAME, e)

    try:
        key = winreg.OpenKey(winreg.HKEY_CURRENT_USER, ENV_REG_PATH, 0, winreg.KEY_SET_VALUE | winreg.KEY_QUERY_VALUE)
        try:
            current, _ = winreg.QueryValueEx(key, ENV_NAME)
            if _has_our_debug_arg(current):
                winreg.DeleteValue(key, ENV_NAME)
                log.info("%s: variable de entorno global antigua eliminada.", DISPLAY_NAME)
        except FileNotFoundError:
            pass
        winreg.CloseKey(key)
        os.environ.pop(ENV_NAME, None)
        _broadcast_environment_change()
    except FileNotFoundError:
        pass
    except Exception as e:
        log.error("%s: Error limpiando variable global antigua: %s", DISPLAY_NAME, e)

def write_user_environment_argument():
    if not USE_WILDCARD_AND_USER_ENVIRONMENT:
        return
    try:
        os.environ[ENV_NAME] = DEBUG_ARG
        key = winreg.CreateKey(winreg.HKEY_CURRENT_USER, ENV_REG_PATH)
        winreg.SetValueEx(key, ENV_NAME, 0, winreg.REG_SZ, DEBUG_ARG)
        winreg.CloseKey(key)
        _broadcast_environment_change()
        log.info("%s: Variable de entorno de usuario configurada.", DISPLAY_NAME)
    except Exception as e:
        log.error("%s: No se pudo configurar variable de entorno: %s", DISPLAY_NAME, e)


def remove_user_environment_argument():
    try:
        os.environ.pop(ENV_NAME, None)
        key = winreg.OpenKey(winreg.HKEY_CURRENT_USER, ENV_REG_PATH, 0, winreg.KEY_SET_VALUE | winreg.KEY_QUERY_VALUE)
        try:
            current, _ = winreg.QueryValueEx(key, ENV_NAME)
            if current == DEBUG_ARG or _has_our_debug_arg(current):
                winreg.DeleteValue(key, ENV_NAME)
                log.info("%s: Variable de entorno de usuario eliminada.", DISPLAY_NAME)
        except FileNotFoundError:
            pass
        winreg.CloseKey(key)
        _broadcast_environment_change()
    except FileNotFoundError:
        pass
    except Exception as e:
        log.error("%s: Error eliminando variable de entorno: %s", DISPLAY_NAME, e)


def write_registry_policy():
    cleanup_old_configuration()
    names = registry_value_names()
    for key_path in REG_PATHS:
        try:
            key = winreg.CreateKey(winreg.HKEY_CURRENT_USER, key_path)
            for name in names:
                winreg.SetValueEx(key, name, 0, winreg.REG_SZ, DEBUG_ARG)
            winreg.CloseKey(key)
            log.info("%s: Registro configurado en %s para: %s", DISPLAY_NAME, key_path, ", ".join(names))
        except Exception as e:
            log.error("%s: No se pudo escribir %s: %s", DISPLAY_NAME, key_path, e)
    write_user_environment_argument()


def cleanup_registry_policy():
    names = list(dict.fromkeys(BASE_APP_KEYS + discover_target_app_ids() + LEGACY_GENERIC_KEYS))
    for key_path in REG_PATHS:
        try:
            key = winreg.OpenKey(winreg.HKEY_CURRENT_USER, key_path, 0, winreg.KEY_SET_VALUE | winreg.KEY_QUERY_VALUE)
            for name in names:
                try:
                    current, _ = winreg.QueryValueEx(key, name)
                    if current == DEBUG_ARG or _has_our_debug_arg(current):
                        winreg.DeleteValue(key, name)
                        log.info("%s: Registro limpiado en %s para %s", DISPLAY_NAME, key_path, name)
                except FileNotFoundError:
                    pass
            winreg.CloseKey(key)
        except FileNotFoundError:
            pass
        except Exception as e:
            log.error("%s: Error limpiando registro: %s", DISPLAY_NAME, e)
    remove_user_environment_argument()


def is_debug_port_open():
    try:
        with socket.create_connection(("127.0.0.1", DEBUG_PORT), timeout=1.0):
            return True
    except Exception:
        return False


class WhatsAppVoiceThread(threading.Thread):
    def __init__(self, js_code):
        super().__init__()
        self.daemon = True
        self.js_code = js_code
        self.running = True
        self.connected_url = None
        self.last_status = "Iniciando"
        self.last_error = ""
        self.last_targets = []
        self.inject_count = 0

    def run(self):
        self.last_status = "%s: esperando puerto %d. Pulse NVDA+Control+Shift+W dos veces para iniciar el modo dual." % (TARGET_NAME, DEBUG_PORT)
        while self.running:
            try:
                if not self.connected_url:
                    ws_url = self.find_whatsapp_ws_url()
                    if ws_url:
                        log.info("%s: Puerto detectado. Conectando a %s", DISPLAY_NAME, ws_url)
                        self.inject_and_hold(ws_url)
                    else:
                        if is_debug_port_open():
                            self.last_status = "%s: puerto abierto, esperando página de WhatsApp" % TARGET_NAME
                        else:
                            self.last_status = "%s: esperando puerto %d. Pulse NVDA+Control+Shift+W dos veces para iniciar el modo dual." % (TARGET_NAME, DEBUG_PORT)
                time.sleep(3)
            except Exception as e:
                self.last_error = str(e)
                self.last_status = "%s: error en bucle de inyección" % TARGET_NAME
                log.error("%s: Error en bucle de inyección: %s", DISPLAY_NAME, e)
                time.sleep(3)

    def get_json_targets(self):
        last_exc = None
        for endpoint in ("json/list", "json"):
            try:
                url = "http://127.0.0.1:%d/%s" % (DEBUG_PORT, endpoint)
                req = urllib.request.Request(url)
                with urllib.request.urlopen(req, timeout=2.0) as response:
                    return json.loads(response.read().decode("utf-8"))
            except Exception as e:
                last_exc = e
        raise last_exc or Exception("No se pudo leer lista CDP")

    def find_whatsapp_ws_url(self):
        try:
            data = self.get_json_targets()
            self.last_targets = data if isinstance(data, list) else []
            for target in self.last_targets:
                t_type = target.get("type", "")
                t_url = target.get("url", "")
                title = target.get("title", "")
                ws_url = target.get("webSocketDebuggerUrl", "")
                combined = (t_url + " " + title).lower()
                if t_type == "page" and ws_url and ("web.whatsapp.com" in combined or "whatsapp" in combined):
                    return ws_url
            for target in self.last_targets:
                if target.get("type") == "page" and target.get("webSocketDebuggerUrl"):
                    return target.get("webSocketDebuggerUrl")
        except Exception as e:
            self.last_error = str(e)
        return None

    def inject_and_hold(self, ws_url):
        client = None
        try:
            client = MinWSClient(ws_url)
            client.connect()
            self.connected_url = ws_url
            self.last_status = "%s: conectado al WebView" % TARGET_NAME
            self.last_error = ""

            commands = [
                {"id": 1, "method": "Page.enable"},
                {"id": 2, "method": "Runtime.enable"},
                {"id": 3, "method": "Page.addScriptToEvaluateOnNewDocument", "params": {"source": self.js_code}},
                {"id": 4, "method": "Runtime.evaluate", "params": {"expression": self.js_code, "awaitPromise": False}},
            ]
            for cmd in commands:
                client.send_text(json.dumps(cmd))
                time.sleep(0.15)

            self.inject_count += 1
            log.info("%s: Script inyectado.", DISPLAY_NAME)
            self.last_status = "%s: conectado e inyectado. Prueba grabar un audio nuevo." % TARGET_NAME

            client.sock.settimeout(1.0)
            while self.running:
                try:
                    data = client.sock.recv(1024)
                    if not data:
                        log.info("%s: WebSocket cerrado por WhatsApp.", DISPLAY_NAME)
                        break
                except socket.timeout:
                    try:
                        client.send_text(json.dumps({
                            "id": 9000 + self.inject_count,
                            "method": "Runtime.evaluate",
                            "params": {"expression": "window.__dextopWhatsappVoiceStatus || 'sin estado'"}
                        }))
                    except Exception:
                        log.info("%s: Canal WebSocket perdido.", DISPLAY_NAME)
                        break
                time.sleep(5)
        except Exception as e:
            self.last_error = str(e)
            self.last_status = "%s: error al inyectar" % TARGET_NAME
            log.error("%s: Error durante inyección CDP: %s", DISPLAY_NAME, e)
        finally:
            if client:
                client.close()
            self.connected_url = None


class GlobalPlugin(globalPluginHandler.GlobalPlugin):
    def __init__(self):
        super().__init__()
        if globalVars.appArgs.secure:
            log.warning("%s: Deshabilitado en pantallas seguras.", DISPLAY_NAME)
            raise ValueError(_("This add-on cannot be run on secure screens."))
        log.info("%s: Inicializando complemento 1.8.0 modo dual interno.", DISPLAY_NAME)
        self.thread = None
        try:
            current_dir = os.path.dirname(__file__)
            js_path = os.path.join(current_dir, "accessibility_and_audio_bridge.js")
            with open(js_path, "r", encoding="utf-8") as f:
                js_code = f.read()
            self.thread = WhatsAppVoiceThread(js_code)
            self.thread.start()
            log.info("%s: Hilo iniciado.", DISPLAY_NAME)
        except Exception as e:
            log.error("%s: No se pudo cargar JS o iniciar hilo: %s", DISPLAY_NAME, e)

    def terminate(self):
        log.info("%s: Terminando complemento.", DISPLAY_NAME)
        if self.thread:
            self.thread.running = False
            self.thread.join(timeout=2.0)
        super().terminate()

    if script:
        @script(description=_("Check Dextop WhatsApp Voice Beta status"), gesture="kb:NVDA+shift+v")
        def script_checkVoiceStatus(self, gesture):
            msg = DISPLAY_NAME + ": "
            if not self.thread:
                msg += "el hilo no inició."
            elif self.thread.connected_url:
                msg += "conectado e inyectado."
            else:
                msg += self.thread.last_status
                if self.thread.last_error:
                    msg += ". Error: " + self.thread.last_error
            if ui:
                ui.message(msg)
            log.info(msg)

        @script(description=_("Rewrite WebView2 registry keys for Dextop WhatsApp Voice Beta"))
        def script_rewriteVoiceRegistry(self, gesture):
            msg = "%s: para configurar Beta use NVDA+Control+Shift+W dos veces e inicie el modo dual." % DISPLAY_NAME
            if self.thread:
                self.thread.last_status = msg
                self.thread.last_error = ""
            if ui:
                ui.message(msg)
            log.info(msg)

        @script(description=_("Disable Dextop WhatsApp Voice Beta WebView2 configuration"))
        def script_disableVoiceConfig(self, gesture):
            cleanup_registry_policy()
            msg = "%s: configuración desactivada. Cierra y vuelve a abrir %s para quitar el puerto." % (DISPLAY_NAME, TARGET_NAME)
            if self.thread:
                self.thread.last_status = msg
                self.thread.last_error = ""
            if ui:
                ui.message(msg)
            log.info(msg)
