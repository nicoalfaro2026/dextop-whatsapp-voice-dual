# -*- coding: utf-8 -*-
import logging
import os
import winreg

log = logging.getLogger("nvda.dextop_whatsapp_voice_dual.installTasks")
ENV_NAME = "WEBVIEW2_ADDITIONAL_BROWSER_ARGUMENTS"

NAMES = [
    '5319275A.WhatsAppDesktop_cv1g1gvanyjgm!App',
    '5319275A.WhatsAppDesktop_cv1g1gvanyjgm',
    '5319275A.WhatsAppDesktop',
    '5319275A.51895FA4EA97F_cv1g1gvanyjgm!App',
    '5319275A.51895FA4EA97F_cv1g1gvanyjgm',
    '5319275A.51895FA4EA97F',
    # Restos de versiones anteriores que pisaban Desktop/Beta:
    'WhatsApp.Root.exe', 'WhatsApp.exe', 'WhatsAppDesktop.exe',
    'WhatsAppBeta.exe', 'WhatsApp.Beta.exe', 'WhatsAppDesktopBeta.exe',
    'WhatsAppBeta', 'WhatsApp.WhatsAppBeta',
    '5319275A.WhatsAppBeta', '5319275A.WhatsAppBeta_cv1g1gvanyjgm',
    '5319275A.WhatsAppBeta_cv1g1gvanyjgm!App',
    '5319275A.WhatsAppBeta_cv1g1gvanyjgm!WhatsApp',
    '5319275A.WhatsAppBeta_cv1g1gvanyjgm!WhatsAppBeta',
    '5319275A.WhatsAppDesktop_cv1g1gvanyjgm!WhatsApp',
    'Chrome._crx_hnpfjngllnfapefoaidbinmjnm', '*'
]
PATHS = [
    r"Software\Policies\Microsoft\Edge\WebView2\AdditionalBrowserArguments",
    r"Software\Microsoft\Edge\WebView2\AdditionalBrowserArguments",
]


def _is_ours(value):
    text = str(value or "")
    return "remote-debugging-port=59222" in text or "remote-debugging-port=59223" in text


def _delete_if_ours(key, name):
    try:
        current, _ = winreg.QueryValueEx(key, name)
        if _is_ours(current):
            winreg.DeleteValue(key, name)
            log.info("Dextop WhatsApp Voice Dual: se eliminó %s", name)
    except FileNotFoundError:
        pass


def onUninstall():
    """Limpieza automática al desinstalar el complemento."""
    log.info("Dextop WhatsApp Voice Dual: Ejecutando tareas de desinstalación...")
    for key_path in PATHS:
        try:
            key = winreg.OpenKey(winreg.HKEY_CURRENT_USER, key_path, 0, winreg.KEY_SET_VALUE | winreg.KEY_QUERY_VALUE)
            for name in NAMES:
                _delete_if_ours(key, name)
            winreg.CloseKey(key)
        except FileNotFoundError:
            pass
        except Exception as e:
            log.error("Dextop WhatsApp Voice Dual: Error al limpiar %s: %s", key_path, e)

    try:
        key = winreg.OpenKey(winreg.HKEY_CURRENT_USER, r"Environment", 0, winreg.KEY_SET_VALUE | winreg.KEY_QUERY_VALUE)
        _delete_if_ours(key, ENV_NAME)
        winreg.CloseKey(key)
        os.environ.pop(ENV_NAME, None)
    except FileNotFoundError:
        pass
    except Exception as e:
        log.error("Dextop WhatsApp Voice Dual: Error al limpiar variable de entorno: %s", e)
